using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManagerS : MonoBehaviour
{
    public static GameManagerS instance; // Singleton para acceder al GameManager desde otros scripts

    public float miGameManager; // Cambiado el nombre de la variable
    public float puntuacion; // Variable para la puntuación del juego

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Hacer que el objeto GameManager sea persistente
        }
        else
        {
            Destroy(gameObject); // Evitar duplicados del GameManager
        }
    }

    // Método para reiniciar la puntuación
    public void ReiniciarPuntuacion()
    {
        puntuacion = 0;
    }

    // Método para cargar una nueva escena por nombre
    public void CargarEscena(string nombreEscena)
    {
        SceneManager.LoadScene(nombreEscena);
    }

    // Agrega más lógica del juego, como métodos para aumentar la puntuación, gestionar niveles, etc.

    
    

}
