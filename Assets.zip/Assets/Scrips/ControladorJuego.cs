using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // Necesario para trabajar con componentes de UI

public class GameManager : MonoBehaviour
{
    public float tiempoRestante = 60.0f; // Tiempo inicial en segundos
    public Text tiempoText; // Referencia al Text que muestra el tiempo
    public bool todasManzanasRecogidas = false; // Variable para verificar si se recogieron todas las manzanas

    void Update()
    {
        // Restar tiempo
        tiempoRestante -= Time.deltaTime;

        // Actualizar el Texto con el tiempo restante
        tiempoText.text = "Tiempo: " + Mathf.Round(tiempoRestante);

        // Comprobar si se ha agotado el tiempo y no se recogieron todas las manzanas
        if (tiempoRestante <= 0 && !todasManzanasRecogidas)
        {
            // Mostrar Game Over
            tiempoText.text = "Game Over";
            // Puedes agregar aquí cualquier acción adicional que desees realizar cuando el juego termine.
        }
    }
}
