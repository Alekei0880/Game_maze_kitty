using UnityEngine;
using UnityEngine.SceneManagement;
public class Manzana : MonoBehaviour
{
    public GameObject efectoPrefab;
    public float cantidadPuntos;
    public Puntaje puntaje;
    public AudioSource nom;

    // No necesitas declarar una nueva variable "numeroDeManzanas" aquí

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Kitty"))
        {
            if (efectoPrefab != null)
            {
                nom.Play();
                Instantiate(efectoPrefab, transform.position, Quaternion.identity);

                puntaje.SumarPuntosa(cantidadPuntos);
                ContadorManzanas.numeroDeManzanas--;
                Destroy(gameObject);
            }
            if (ContadorManzanas.numeroDeManzanas == 0)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            }
                
            
        }
    }
}
