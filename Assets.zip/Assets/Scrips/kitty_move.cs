using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoJugador : MonoBehaviour
{
    public float velocidadMovimiento = 5.0f;
    private Rigidbody2D rb;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    private Vector2 movimiento;
    private Vector2 direccionActual;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    float GetHorizontalInput()
    {
        return Input.GetAxis("Horizontal");
    }

    float GetVerticalInput()
    {
        return Input.GetAxis("Vertical");
    }

    void FixedUpdate()
    {
        float movimientoHorizontal = GetHorizontalInput();
        float movimientoVertical = GetVerticalInput();

        if (movimientoHorizontal != 0 || movimientoVertical != 0)
        {
            // El jugador presionó una tecla de movimiento, rastreamos la dirección actual
            direccionActual = new Vector2(movimientoHorizontal, movimientoVertical);
        }

        // Movemos al personaje en la dirección actual
        movimiento = direccionActual.normalized * velocidadMovimiento;
        rb.velocity = movimiento;

        // Configurar parámetros de animación
        animator.SetFloat("Horizontal", Mathf.Abs(direccionActual.x));
        animator.SetFloat("Vertical", direccionActual.y);

        // Cambiar la escala para reflejar horizontalmente
        spriteRenderer.flipX = direccionActual.x > 0;

        animator.SetBool("arriba", direccionActual.y > 0);
        animator.SetBool("abajo", direccionActual.y < 0);
    }
}
