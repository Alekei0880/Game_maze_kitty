using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GeneradorLaberinto : MonoBehaviour
{
    public int ancho = 10; // Ancho del laberinto
    public int alto = 10; // Alto del laberinto
    public GameObject paredPrefab; // Prefab de la pared
    public Vector2 tamanoCelda = new Vector2(1, 1); // Tamaño de la celda
    public Vector2Int puntoInicio = Vector2Int.zero; // Coordenadas iniciales de generación
    private Transform[,] celdas; // Matriz de celdas
    public GameObject manzanaPrefab; // Prefab de la manzana
    public float probabilidadManzana = 0.2f; // Probabilidad de generar una manzana (0.2 significa un 20% de probabilidad)

    private void Start()
    {
        GenerarLaberinto();
    }

    // Genera el laberinto
    private void GenerarLaberinto()
    {
        celdas = new Transform[ancho, alto]; // Inicializa la matriz de celdas
        int numeroDeManzanas = 0; // Contador para el número de manzanas en el laberinto

        for (int x = 0; x < ancho; x++) // Recorre las celdas
        {
            for (int y = 0; y < alto; y++) // Recorre las celdas
            {
                Vector2 posicion = new Vector2(x * tamanoCelda.x, y * tamanoCelda.y); // Calcula la posición de la celda
                GameObject pared = Instantiate(paredPrefab, posicion, Quaternion.identity); // Instancia la pared
                celdas[x, y] = pared.transform; // Guarda la referencia de la celda

                
                // Genera una manzana en la celda actual con la probabilidad especificada
                if (!pared.activeSelf) // Comprueba si la celda es un pasillo
                {
                    if (Random.value < probabilidadManzana)
                    {
                        Vector2 posicionManzana = new Vector2(x * tamanoCelda.x, y * tamanoCelda.y);
                        GameObject manzana = Instantiate(manzanaPrefab, posicionManzana, Quaternion.identity);
                        numeroDeManzanas++;
                    }
                }
            }
        }

        // Verifica si el número de manzanas es cero y reinicia el juego si es así
        if (numeroDeManzanas == 0)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        // Inicia la generación en una celda aleatoria
        GenerarDesdeCelda(Random.Range(0, ancho), Random.Range(0, alto));
    }

    // Genera el laberinto desde la celda especificada
    private void GenerarDesdeCelda(int x, int y)
    {
        int numeroDeManzanas = 0; // Contador para el número de manzanas en el laberinto
        GameObject pared = celdas[x, y].gameObject; // Obtiene la celda actual
        celdas[x, y].gameObject.SetActive(false); // Convierte la celda en pasillo
        if (!pared.activeSelf) // Comprueba si la celda es un pasillo
        {
            if (Random.value < probabilidadManzana)
            {
                Vector2 posicionManzana = new Vector2(x * tamanoCelda.x, y * tamanoCelda.y);
                GameObject manzana = Instantiate(manzanaPrefab, posicionManzana, Quaternion.identity);
                numeroDeManzanas++;
            }
        }
        // Baraja aleatoriamente las direcciones
        List<Vector2Int> direcciones = ObtenerDireccionesAleatorias();
        foreach (Vector2Int direccion in direcciones)
        {
            int nx = x + direccion.x * 2;
            int ny = y + direccion.y * 2;

            if (EstaDentroDelLaberinto(nx, ny) && celdas[nx, ny].gameObject.activeSelf)
            {
                celdas[x + direccion.x, y + direccion.y].gameObject.SetActive(false);
                GenerarDesdeCelda(nx, ny);
            }
        }
    }

    // Devuelve una lista de direcciones barajadas aleatoriamente
    private List<Vector2Int> ObtenerDireccionesAleatorias()
    {
        // Lista de direcciones
        List<Vector2Int> direcciones = new List<Vector2Int>
        {
            new Vector2Int(0, 1), // Arriba
            new Vector2Int(0, -1), // Abajo
            new Vector2Int(1, 0), // Derecha
            new Vector2Int(-1, 0) // Izquierda
        };

        // Baraja aleatoriamente las direcciones
        for (int i = 0; i < direcciones.Count; i++)
        {
            Vector2Int temp = direcciones[i];
            int randomIndex = Random.Range(i, direcciones.Count);
            direcciones[i] = direcciones[randomIndex];
            direcciones[randomIndex] = temp;
        }

        return direcciones;
    }

    // Comprueba si las coordenadas están dentro del laberinto
    private bool EstaDentroDelLaberinto(int x, int y)
    {
        // Comprueba si las coordenadas están dentro del laberinto
        return x >= 0 && x < ancho && y >= 0 && y < alto;
    }
}
