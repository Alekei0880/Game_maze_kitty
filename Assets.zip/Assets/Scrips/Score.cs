using UnityEngine;
using TMPro;

public class Score : MonoBehaviour
{
    private TextMeshProUGUI textMesh;

    private void Start()
    {
        textMesh = GetComponent<TextMeshProUGUI>();

        // Mostrar la puntuación final al inicio del juego
        MostrarPuntuacionFinal();
    }

    // Método para mostrar la puntuación final
    public void MostrarPuntuacionFinal()
    {
        // Accede a la puntuación final desde la clase puntacion
        float puntuacionFinal = 0;

        // Muestra la puntuación final en el TextMeshProUGUI
        textMesh.text = GameManagerS.instance.miGameManager.ToString("0");
    }
}
