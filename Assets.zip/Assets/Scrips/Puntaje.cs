using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public static class puntacion 
{
    
    public static float puntacionfinal;
}
public class Puntaje : MonoBehaviour
{
    
    
    private TextMeshProUGUI textMesh;
    public float puntos;


    private void Start()
    {
        textMesh = GetComponent<TextMeshProUGUI>();

    }
    private void Update()
    {
        //puntos += Time.deltaTime;
        textMesh.text = puntos.ToString("0");
    }

    public void SumarPuntosa(float puntosEntrada){
        puntos += puntosEntrada; //puntos = puntos + puntosEntrada;
        GameManagerS.instance.miGameManager = puntos;
        Debug.Log("Puntos: " + puntos);

    }
}
